// C program to remove duplicates
#include <stdio.h>
int main()
{
    int a[20],n,i,j,k;
    printf("How many elements are there in array : ");
    scanf("%d",&n);
    printf("Enter the elements of the array : ");
    for(int i=0;i<n;i++)
    {
        printf("\nEnter element %d : ",i+1);
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(a[i]==a[j])
            {
                for(k=j;k<n-1;k++)
                {
                    a[k]=a[k+1];
                }
                n=n-1;
                j=j-1;
            }
        }
    }
    printf("\nElements of array after deletion of duplicate elements is : ");
    for(i=0;i<n;i++)
    {
        printf("\t%d",a[i]);
    }
    return 0;
}

