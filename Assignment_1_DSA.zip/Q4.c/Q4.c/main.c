//Program to implement 2-D Array Transpose
#include<stdio.h>
void main()
    {
    int a[10][10],t[10][10],m,n,i,j;
    printf("\nEnter rows & columns of array :");
    scanf("%d%d",&m,&n);
    printf("\nEnter elements of array :");
    for(i=0;i<m;i++)
        {
        printf("\nEnter row#%d elements :",i+1);
        for(j=0;j<n;j++)
            scanf("%d",&a[i][j]);
        }
    printf("\nOriginal array is given below :\n");
    for(i=0;i<m;i++)
        {
        for(j=0;j<n;j++)
            {
            printf("%d ",a[i][j]);
            t[j][i]=a[i][j];
            }
        printf("\n");
        }
    //Printing Transpose of matrix
    printf("\nTranspose of matrix is given below :\n");
    for(i=0;i<n;i++)
        {
        for(j=0;j<m;j++)
            {
            printf("%d ",t[i][j]);
            }
        printf("\n");
        }
    }
