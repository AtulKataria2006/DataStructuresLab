#include <stdio.h>
int main()
{
    int arr[30],n,temp,i,j;
    printf("How many elements are there in the array : ");
    scanf("%d",&n);
    printf("\nEnter the elements of array L : ");
    for(i=0;i<n;i++)
    {
        printf("\nEnter element %d : ",i+1);
        scanf("%d",&arr[i]);
    }
    j=n-1;
    i=0;
    while(i<j)
    {
        temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
        i++;
        j--;
    }
    printf("\nOriginal array is : \n");
    for(i=0;i<n;i++)
    {
        printf("\t%d",arr[i]);
    }
}
