//Program to muplitpy two 2-D arrays
#include<stdio.h>
void main()
{
    int a[10][10],b[10][10],c[10][10],m,n,p,q,i,j,k;
    printf("\nEnter size of first array :");
    scanf("%d%d",&m,&n);
    printf("\nEnter size of second array :");
    scanf("%d%d",&p,&q);
    printf("\nEnter elements of first array :");
    if(n!=p)
    {
        printf("\nProduct not possible..");
    }
    else
    {
        for(i=0;i<m;i++)
        {
            printf("\nEnter elements of row#%d",i+1);
            for(j=0;j<n;j++)
            {
                scanf("%d",&a[i][j]);
            }
        }
        printf("\nEnter elements of second array :");
        for(i=0;i<p;i++)
        {
            printf("\nEnter elements of row#%d",i+1);
            for(j=0;j<q;j++)
            {
                scanf("%d",&b[i][j]);
            }
        }
        //Product of two arrays
        for(i=0;i<m;i++)
        {
            for(j=0;j<q;j++)
            {
                c[i][j]=0;
                for(k=0;k<n;k++)
                    c[i][j]+=a[i][k]*b[k][j];
            }
        }
        //Printing element of third array
        printf("\nNew array is : \n");
        for(i=0;i<m;i++)
        {
            for(j=0;j<q;j++)
            {
                printf("\t%d ",c[i][j]);
            }
            printf("\n");
        }
    }
}
