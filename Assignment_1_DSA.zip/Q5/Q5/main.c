//Program to find row-wise and column-wise sum of elements of array
#include<stdio.h>
void main()
    {
    int a[10][10],m,n,p,q,i,j,k,r,c;
    printf("\nEnter size of first array :");
    scanf("%d%d",&m,&n);
    printf("\nEnter elements of array :");
    for(i=0;i<m;i++)
        {
        printf("\nEnter elements of row#%d :",i+1);
        for(j=0;j<n;j++)
            {
            scanf("%d",&a[i][j]);
            }
        }
    //Row-wise sum of elements of array
    for(i=0;i<m;i++)
        {
        r=0;
        for(j=0;j<n;j++)
            {
            r+=a[i][j];
            }
        printf("\nSum of elements of row#%d is :",i+1);
        printf("%d",r);
        }
    //Column-wise sum of elements of array
    for(i=0;i<n;i++)
        {
        c=0;
        for(j=0;j<m;j++)
            c+=a[j][i];
        printf("\nSum of elements of column#%d is :",i+1);
        printf("%d",c);
        }
    }
