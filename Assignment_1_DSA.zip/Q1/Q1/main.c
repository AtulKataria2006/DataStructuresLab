#include<stdio.h>
int Insertion(int arr[],int n)
{
    int pos,item,i;
    printf("\Enter the element you want to insert : ");
    scanf("%d",&item);
    printf("\nEnter the position where u want to insert the element : ");
    scanf("%d",&pos);
    n=n+1;
    for(i=n-1;i>=pos-1;i--)
    {
        arr[i+1]=arr[i];
    }
    arr[pos-1]=item;
    printf("\nNew array after insertion is : ");
    for(i=0;i<n;i++)
    {
        printf("\t%d",arr[i]);
    }
    return 0;
}
int Deletion(int arr[],int n)
{
    int pos,i;
    printf("\nEnter the position where u want to delete the element : ");
    scanf("%d",&pos);
    for(i=pos-1;i<n-1;i++)
    {
        arr[i]=arr[i+1];
    }
    n=n-1;
    printf("\nNew array after deletion is : ");
    for(i=0;i<n;i++)
    {
        printf("\t%d",arr[i]);
    }
    return 0;
}
int LinearSearch(int arr[],int n)
{
    int item,i;
    printf("\nEnter the element you want to search : ");
    scanf("%d",&item);
    for(i=0;i<n;i++)
    {
        if(arr[i]==item)
        {
            printf("\nItem found at index position %d ",i+1);
        }
        continue;
        
    }
    printf("\nitem not found  ");
    return 0;
}
int main()
{
    int arr[100],i,j,size,choice,ele,flag,a,b,c,n;
    while(choice!=6)
    {
        printf("\n*****M A I N  M E N U*******");
        printf("\n1. CREATE");
        printf("\n2. DISPLAY");
        printf("\n3. INSERT");
        printf("\n4. DELETE");
        printf("\n5. LINEAR SEARCH");
        printf("\n6. EXIT");
        printf("\n\nEnter your choice(1..6):");
        scanf("%d",&choice);
        if(choice==1)
        {
            printf("\nEnter size of array:");
            scanf("%d",&size);
            //Creating array & reading array elements
            printf("\nEnter array elements :");
            for(i=0;i<size;i++)
                scanf("%d",&arr[i]);
        }
        if(choice==2)
        {
            //Printing array elements
            printf("\nElements of created array are :");
            for(i=0;i<size;i++)
                printf("%d\t",arr[i]);
        }
        if(choice==3)
        {
            a=Insertion(arr,n);
        }
        if(choice==4)
        {
            b=Deletion(arr,n);
        }
        if(choice==5)
        {
            //Performing linear search in array
            c=LinearSearch(arr,n);
        }
        if(choice==6)
            break;
    }
    return 0;
}
